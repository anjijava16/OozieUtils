# more info at https://github.com/apache/oozie/tree/master/examples/src/main/apps/hcatalog
# make sure you have a copy of hive-site.xml in your workflow lib folder
