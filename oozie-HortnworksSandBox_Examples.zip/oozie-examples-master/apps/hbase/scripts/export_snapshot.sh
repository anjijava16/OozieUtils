hbase org.apache.hadoop.hbase.snapshot.ExportSnapshot -snapshot tableA-snapshot-2016-05-03 -copy-to hdfs://sandbox.hortonworks.com:8020/user/guest -mappers 16
