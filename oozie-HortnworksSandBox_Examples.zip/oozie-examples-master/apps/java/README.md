#### This is an implementation of example 2 at this [link](https://cwiki.apache.org/confluence/display/OOZIE/Java+Cookbook)
